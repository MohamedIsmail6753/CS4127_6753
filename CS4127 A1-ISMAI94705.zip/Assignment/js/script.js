// Contact Form :
// Finds the contact form
let contactForm = document.getElementById("contactForm");

// Only runs this code if the contact form exists
if (contactForm != null) {

    // Runs when the visitor submits the form
    contactForm.addEventListener("submit", function(event) {

        // Stops the page from reloading
        event.preventDefault();

        // Gets the values entered into the form
        let fullname = document.getElementById("fullname").value;
        let email = document.getElementById("email").value;
        let subject = document.getElementById("subject").value;
        let message = document.getElementById("message").value;

        // Finds the paragraph for displaying feedback
        let formMessage = document.getElementById("formMessage");

        // Checks if any required field is empty
        if (fullname.trim() == "" ||
            email.trim() == "" ||
            subject == "" ||
            message.trim() == "") {

            // Displays an error message if any field is empty
            formMessage.textContent =
                "Please complete all fields before submitting.";

        } else {

            // Displays a confirmation message when the form is complete
            formMessage.textContent =
                "Thank you! " + fullname +
                " Your form has been checked successfully. " +
                "This is a demonstration, so no message was sent.";

        }

    });

    // Clears the feedback when the form is reset
    contactForm.addEventListener("reset", function() {

        document.getElementById("formMessage").textContent = "";

    });

}


// Dark Mode Button : 
// Finds the theme button
let themeButton = document.getElementById("themeButton");

// Only runs this code if the button exists
if (themeButton != null) {

    // Runs when the visitor clicks the button
    themeButton.addEventListener("click", function() {

        // Turns dark mode on or off
        document.body.classList.toggle("dark-mode");

        // Checks whether dark mode is active
        if (document.body.classList.contains("dark-mode")) {

            // Changes button text to Light Mode
            themeButton.textContent = "Light Mode";

        } else {

            // Changes button text Dark Mode
            themeButton.textContent = "Dark Mode";

        }

    });

}


// Interactive Attractions Gallery : 
// Finds the three gallery buttons
let mosqueButton = document.getElementById("mosqueButton");
let villageButton = document.getElementById("villageButton");
let forestButton = document.getElementById("forestButton");

// Finds the elements that will change
let attractionImage = document.getElementById("attractionImage");
let attractionName = document.getElementById("attractionName");
let attractionDescription = document.getElementById("attractionDescription");

// Only runs this code on the Attractions page
if (mosqueButton != null &&
    villageButton != null &&
    forestButton != null &&
    attractionImage != null &&
    attractionName != null &&
    attractionDescription != null) {

    // MOSQUE BUTTON
    mosqueButton.addEventListener("click", function() {

        // Changes the photograph
        attractionImage.src = "images/mosque.jpg";
        attractionImage.alt = "Omar Ali Saifuddien Mosque in Brunei";

        // Changes the heading
        attractionName.textContent =
            "Omar Ali Saifuddien Mosque";

        // Changes the description
        attractionDescription.textContent =
            "A famous mosque in Bandar Seri Begawan, " +
            "known for its golden dome and beautiful architecture.";

    });

    // WATER VILLAGE BUTTON :
    villageButton.addEventListener("click", function() {

        attractionImage.src = "images/kampongayer.jpg";
        attractionImage.alt = "Traditional houses in Kampong Ayer";

        attractionName.textContent = "Kampong Ayer";

        attractionDescription.textContent =
            "A historic water village with traditional houses " +
            "built on stilts above the Brunei River.";

    });

    // RAINFOREST BUTTON :
    forestButton.addEventListener("click", function() {

        attractionImage.src = "images/temburong.jpg";
        attractionImage.alt =
            "Tropical rainforest in Ulu Temburong National Park";

        attractionName.textContent =
            "Temburong National Park";

        attractionDescription.textContent =
            "A protected tropical rainforest known for its " +
            "wildlife, beautiful scenery and canopy walkway.";

    });

}
